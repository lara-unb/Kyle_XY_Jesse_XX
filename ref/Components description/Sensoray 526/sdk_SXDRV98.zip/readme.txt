SxDriver Installation Instructions for Windows2000/XP
=====================================================

September, 2003


1. Copy sxdrv98.sys to
     \Winnt\system32\drivers (Windows2000);
     \Windows\system32\drivers (WindowsXP)
  replacing the old file.

2. Reboot the system.
