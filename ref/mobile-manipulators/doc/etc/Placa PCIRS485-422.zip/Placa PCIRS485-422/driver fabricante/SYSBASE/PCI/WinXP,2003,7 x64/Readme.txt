Readme.txt for MultiPort/PCI Windows XP x64 edition device driver

Jul. 13, 2006. SystemBase Co., Ltd. 



Notices ------------------------------------------------------------

Don't run mpciuninst.exe directly here to uninstall device. 
Use "Add or Remove Programs" in Control Panel instead.
