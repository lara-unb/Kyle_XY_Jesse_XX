Readme.txt for MultiPort/PCI Windows 9x/200x/XP device driver

Jul. 13, 2006. SystemBase Co., Ltd. 



File descriptions --------------------------------------------------

Install.exe : Driver Configurator for Windows 9x platform

Unsbmp.exe : Uninstaller of Configurator for Windows 9x platform

Uninstall_w2k.exe : Device Remover for Windows XP/2000/2003 platform



Notices ------------------------------------------------------------

Don't run unsbmp.exe directly here to uninstall configurator. 
Run "Uninstall" in "SystemBase MultiPort/PCI" program group instead.


